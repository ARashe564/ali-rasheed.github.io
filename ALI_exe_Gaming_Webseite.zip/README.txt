ALI.exe — persönliche Gaming-Webseite

Dateien:
- index.html: vollständige, responsive Webseite mit CSS und JavaScript direkt eingebettet.

So nutzt du sie:
1. Öffne index.html im Browser, um sie lokal anzusehen.
2. Lade index.html auf einen Webhoster hoch, um sie öffentlich erreichbar zu machen.
3. Für einen öffentlich erreichbaren Link benötigst du einen Hosting-Anbieter und eine Domain oder dessen öffentliche Hosting-Adresse.

Enthalten:
- Gaming-Look, responsive Navigation und animierte Seitenwechsel
- Startseite, Über mich, Projekte, Blog, Lernplan und Kontakt
- Projekte, Blog und Lernplan absichtlich als leere/Coming-soon-Bereiche
- Kontakt und Über mich mit kurzem Inhalt
- Datenschutz-/Impressum-Platzhalter ohne private Anschrift und ohne Angaben zum Werdegang

Wichtig:
- Ein öffentlicher Link entsteht nicht allein durch die HTML-Datei. Die Seite muss veröffentlicht/gehostet werden.
- Vor Veröffentlichung bitte Impressum und Datenschutzhinweise passend zu Hosting und konkreter Nutzung rechtlich prüfen/ergänzen.
- Die Telefonnummer und E-Mail-Adresse sind in der Kontaktseite und im Footer/Kontaktbereich sichtbar.
